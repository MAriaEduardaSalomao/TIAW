$(function() {
  var current_fs, next_fs, previous_fs;


  $('.next').click(function() {
    current_fs = $(this).closest('fieldset');
    next_fs = current_fs.next();


    $('#progress li').eq($('fieldset').index(next_fs)).addClass('active');


    current_fs.hide(800);
    next_fs.show(800);
  });


  $('.prev').click(function() {
    current_fs = $(this).closest('fieldset');
    previous_fs = current_fs.prev();


    $('#progress li').eq($('fieldset').index(current_fs)).removeClass('active');


    current_fs.hide(800);
    previous_fs.show(800);
  });


  $('#form').submit(function() {
    return false;
  });
});


function redirecionar() {
   window.location.href = '..paginas/cadastro.html'
}

function redirecionarParaCadastro() {
   window.location.href = '/index.html'
}



const getLocalStorage = () => JSON.parse(localStorage.getItem('db_client')) ?? [];
const setLocalStorage = (dbClient) => localStorage.setItem('db_client', JSON.stringify(dbClient));




const createClient = (client) => {
  const dbClient = getLocalStorage()
  console.log(dbClient)
  dbClient.push(client)
  setLocalStorage(dbClient)

}




const readCliente = () => getLocalStorage()



const deleteCliente = (index) => {
  const dbClient = readCliente()
  dbClient.splice(index, 1)
  setLocalStorage(dbClient)
}


const salvarClient = () => {
  if (campoValido()) {
    const client = {

      matricula: document.getElementById('matricula').value,
      endereco: document.getElementById('endereco').value,
      cidade: document.getElementById('cidade').value,
      estado: document.getElementById('uf').value,
      cep: document.getElementById('cep').value,
      numero: document.getElementById('numero').value,
      complemento: document.getElementById('complemento').value,
      curso: document.getElementById('curso').value,
    }
    createClient(client)
    atualizarTabela();

  }
}


const campoValido = () => {
  return document.getElementById('form').reportValidity()
}




const createRow = (client, index) => {
  const newRow = document.createElement('tr')
  newRow.innerHTML =
    `
        <td>${client.matricula}</td>
        <td>${client.endereco}</td>
        <td>${client.cidade}</td>
        <td>${client.estado}</td>
        <td>${client.cep}</td>
        <td>${client.numero}</td>
        <td>${client.complemento}</td>
        <td>${client.curso}</td>

      <div><button type = "button" id = "delete-${index}">Excluir</button>
    </div>

    `
  document.querySelector('#tabela>tbody').appendChild(newRow)

}



const atualizarTabela = () => {
  const dbClient = readCliente()
  clearTable()
  dbClient.forEach(createRow)

}


const clearTable = () => {
  const rows = document.querySelectorAll('#tabela>tbody tr')
  rows.forEach(row => row.parentNode.removeChild(row))
}




const editDelete = (event) => {
  if (event.target.type == 'button') {
    const [action, index] = event.target.id.split('-')

    if (action == 'edit') {
      editClient(index)
    }

    else {
      const client = readCliente()[index]
      const response = confirm(`Deseja realmente excluir o cliente com matrícula ${client.matricula}`)
      if (response) {
        deleteCliente(index)
        atualizarTabela()
      }
    }
  }

}


atualizarTabela();

document.getElementById('salvar').addEventListener('click', salvarClient)

document.querySelector('#tabela>tbody')
  .addEventListener('click', editDelete)





const nome = document.getElementById('campoNome')
const email = document.getElementById('campoEmail')
const senha = document.getElementById('campoSenha')



function redirecionar() {
  window.location.href = 'cadastro.html'
}


function cadastrar() {
  let nome = document.getElementById('campoNome');
  let email = document.getElementById('campoEmail');
  let senha = document.getElementById('campoSenha');
  let msgSuccess = document.getElementById('msgSuccess');
  let msgError = document.getElementById('msgError');

  let listaUser = JSON.parse(localStorage.getItem('listaUser') || '[]');

  listaUser.push({
    nomeCard: nome.value,
    emailCard: email.value,
    senhaCard: senha.value
  });

  localStorage.setItem('listaUser', JSON.stringify(listaUser));
  console.log(listaUser);

  msgSuccess.setAttribute('style', 'display: block');
  msgSuccess.innerHTML = 'Cadastro realizado com sucesso!';
  msgError.setAttribute('style', 'display: none');
  msgError.innerHTML = '';
}







