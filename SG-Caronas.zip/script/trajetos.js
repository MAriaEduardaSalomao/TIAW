function escolhePassag() {
    document.getElementById('psg1').style.display = 'inline-block';    
    document.getElementById('psg2').style.display = 'inline-block';
    document.getElementById('psg3').style.display = 'inline-block';
    document.getElementById('psgX').style.display = 'inline-block';

}
var passageiro = {};
passageiro.nome = "Passageiro 1";
passageiro.endereco = "Rua A, 123";
passageiro.nota = "4,8";

var passageiroX = {};
passageiroX.nome = "Passageiro X";
passageiroX.endereco = "Rua B, 32";
passageiroX.nota = "4,0";

var passageiro4 = {};
passageiro4.nome = "Passageiro 4";
passageiro4.endereco = "Rua C, 44";
passageiro4.nota = "4,4";

var passageiro2 = {};
passageiro2.nome = "Passageiro 2";
passageiro2.endereco = "Rua D, 28";
passageiro2.nota = "5,0";

var passageiro3 = {};
passageiro3.nome = "Passageiro X";
passageiro3.endereco = "Rua E, 47";
passageiro3.nota = "4,2";

var passageiroY = {};
passageiroY.nome = "Passageiro Y";
passageiroY.endereco = "Rua F, 67";
passageiroY.nota = "3,8";

var Passageiros = [passageiro, passageiroX, passageiro4, passageiro2, passageiro3, passageiroY];
JSON.stringify(Passageiros);

const todosPassageiros = [
    {
        "nome": "Passageiro 1",
        "endereco": "Rua A, 123",
        "nota": "4,8"
    },
    {
        "nome": "Passageiro X",
        "endereco": "Rua B, 32",
        "nota": "4,0"
    },
    {
        "nome": "Passageiro 4",
        "endereco": "Rua C, 44",
        "nota": "4,4"
    },
    {
        "nome": "Passageiro 2",
        "endereco": "Rua D, 28",
        "nota": "5,0"
    },
    {
        "nome": "Passageiro X",
        "endereco": "Rua E, 47",
        "nota": "4,2"
    },
    {
        "nome": "Passageiro Y",
        "endereco": "Rua F, 67",
        "nota": "3,8"
    }
]



function abreMapa() {
    document.getElementById('mapa').style.display = 'block';
    document.getElementById('mapa').style.zIndex = "1300";
    document.getElementById('mapa').style.width = "1200px";
    document.getElementById('mapa').style.height = "700px";
}
